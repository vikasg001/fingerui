This folder contains various data that is used by cv libraries and/or demo applications.
----------------------------------------------------------------------------------------

haarcascades - the folder contains trained classifiers for detecting objects
               of a particular type, e.g. faces (frontal, profile), pedestrians etc.
               Some of the classifiers have a special license - please,
               look into the files for details.

var canvas = document.getElementById('canvas');
var video = document.getElementById('video');


window.onload = function () {
    console.log('window - onload'); // 4th
    init();
    getCount();
};

function init() {
    const constraints = {
        audio: false,
        video: {
            width: 1920, height: 1080
        }
    };

    navigator.getUserMedia = navigator.getUserMedia || navigator['webkitGetUserMedia'] || navigator['mozGetUserMedia'];

    if (navigator.getUserMedia) {
        navigator.getUserMedia(constraints,
            (stream) => {
                var video = document.querySelector('video');
                video.srcObject = stream;
                video.onloadedmetadata = (e) => {
                    video.play();
                };
            },
            (err) => {

            }
        );
    }
}

function getCount() {
    const likeEle = document.getElementById('like-count');
    const neutralEle = document.getElementById('neutral-count');
    const dislikeEle = document.getElementById('dislike-count');
    $.ajax({
        type: 'GET',
        url: 'https://jsonplaceholder.typicode.com/todos/1',
        data: { get_param: 'value' },
        dataType: 'json',
        success: function (data) {
            console.log(data);
            likeEle.innerText = '12';
            neutralEle.innerText = '10';
            dislikeEle.innerText = '11';
        }
    });
}
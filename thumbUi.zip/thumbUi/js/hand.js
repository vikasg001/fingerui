const video = document.getElementById('video');
video.style.display = 'none';
const canvas = document.getElementById('canvasoutput');
const context = canvas.getContext('2d');
const customCanvas = document.getElementById('customcanvas');
const ctx = customCanvas.getContext('2d');
let updateNote = document.getElementById("updatenote");
updateNote.innerText = "Video Streaming Starting.....";
const modelParams = {
    flipHorizontal: true,   // flip e.g for video 
    imageScaleFactor: 0.7,  // reduce input image size for gains in speed.
    maxNumBoxes: 1,        // maximum number of boxes to detect
    iouThreshold: 0.79,      // ioU threshold for non-max suppression
    scoreThreshold: 0.69,    // confidence threshold for predictions.
};

let model = null;
let isVideo = false;

var lastX, lastY;

navigator.getUserMedia = navigator.getUserMedia ||
    navigator.webkitGetUserMedia ||
    navigator.mozGetUserMedia;

if (navigator.getUserMedia) {
    navigator.getUserMedia({ audio: false, video: { width: 640, height: 480 } },
        function (stream) {
            video.srcObject = stream;
            startVideo();
        },
        function (err) {
            console.log("The following error occurred: " + err.name);
        }
    );
} else {
    console.log("getUserMedia not supported");
}

function startVideo() {
    handTrack.startVideo(video).then(function (status) {
        console.log("video started", status);
        if (status) {
            updateNote.innerText = "Video started. Now tracking";
            isVideo = true;
            runDetection();
        } else {
            updateNote.innerText = "Please enable video";
        }
    });
}

function runDetection() {
    model.detect(video).then(predictions => {    
        model.renderPredictions(predictions, canvas, context, video);
        if (predictions.length > 0) {
            console.log("Predictions: ", predictions);
            let coord = predictions[0].bbox;
            let x = (coord[0] + (coord[0] + coord[2])) / 2;
            let y = (coord[1] + (coord[1] + coord[3])) / 2;
            Draw(x, y);
        }
        
        if (isVideo) {
            requestAnimationFrame(runDetection);
        }
    });
}

function Draw(x, y, isDown = true) {
    if (!!!lastX && !!!lastY) {
        lastX = x; lastY = y;
    }

    if (isDown) {
        //console.log(x, y);
        ctx.beginPath();
        ctx.strokeStyle = "#00000";
        ctx.lineWidth = 5;
        ctx.lineJoin = "round";
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(x, y);
        ctx.closePath();
        ctx.stroke();
    }
    lastX = x; lastY = y;
}

function clearArea() {
    // Use the identity matrix while clearing the canvas
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    lastX = undefined; lastY = undefined;
}


handTrack.load(modelParams).then(get_model => {
    console.info(get_model);
    model = get_model;
});
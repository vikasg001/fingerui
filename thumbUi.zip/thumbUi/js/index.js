const webcamElement = document.getElementById('webcam');
const classifier = knnClassifier.create();
const likeEle = document.getElementById('like-count');
const neutralEle = document.getElementById('neutral-count');
const dislikeEle = document.getElementById('dislike-count');
const trainStatusElement = document.getElementById('train-status');
let likeCount = 0;
let dislikeCount = 0;
let neutralCount = 0;
let webcam;

isPredict = true;

async function app() {
    console.log('Loading mobilenet..');

    // Load the model.
    net = await mobilenet.load();
    console.log('Successfully loaded model');

    // Create an object from Tensorflow.js data API which could capture image 
    // from the web camera as Tensor.
    const webcam = await tf.data.webcam(webcamElement);

    // Reads an image from the webcam and associates it with a specific class
    // index.
    const addExample = async classId => {
        // Capture an image from the web camera.
        const img = await webcam.capture();

        // Get the intermediate activation of MobileNet 'conv_preds' and pass that
        // to the KNN classifier.
        console.log(img);
        const activation = net.infer(img, 'conv_preds');

        // Pass the intermediate activation to the classifier.
        classifier.addExample(activation, classId);

        // Dispose the tensor to release the memory.
        img.dispose();
    };

    // When clicking a button, add an example for that class.
    document.getElementById('class-a').addEventListener('click', () => addExample(0));
    document.getElementById('class-b').addEventListener('click', () => addExample(1));
    document.getElementById('class-c').addEventListener('click', () => addExample(2));

    while (true) {
        if (classifier.getNumClasses() > 0) {
            const img = await webcam.capture();

            // Get the activation from mobilenet from the webcam.
            const activation = net.infer(img, 'conv_preds');
            // Get the most likely class and confidences from the classifier module.
            const result = await classifier.predictClass(activation);

            const classes = ['Like', 'Dislike', 'Neutral'];
            document.getElementById('console').innerText = `
        prediction: ${classes[result.label]}\n
        probability: ${result.confidences[result.label]}
      `;

            if (classes[result.label] === 'Like') {

                likeCount = likeCount + 1;
                likeEle.innerText = likeCount;
            }

            if (classes[result.label] === 'Dislike') {
                dislikeCount = dislikeCount + 1;
                dislikeEle.innerText = dislikeCount;
            }


            if (classes[result.label] === 'Neutral') {
                neutralCount = neutralCount + 1;
                neutralEle.innerText = neutralCount;
            }


            // Dispose the tensor to release the memory.
            img.dispose();
        }

        await tf.nextFrame();
    }
}

//Init();
//app();



function isPredicting() {
    statusElement.style.visibility = 'visible';
}

function donePredicting() {
    statusElement.style.visibility = 'hidden';
}

function trainStatus(status) {
    trainStatusElement.innerText = status;
}



document.getElementById('train').addEventListener('click', async () => {
    trainStatus('Training...');
    await tf.nextFrame();
    await tf.nextFrame();
    isPredict = false;
    train();
});
document.getElementById('predict').addEventListener('click', () => {
    isPredict = true;
    trainStatus('No Training');
    predict();
});


async function train() {

    // Load the model.
    net = await mobilenet.load();
    console.log('Successfully loaded model');

    // Reads an image from the webcam and associates it with a specific class
    // index.
    const addExample = async classId => {
        // Capture an image from the web camera.
        const img = await webcam.capture();

        // Get the intermediate activation of MobileNet 'conv_preds' and pass that
        // to the KNN classifier.
        console.log(img);
        const activation = net.infer(img, 'conv_preds');

        // Pass the intermediate activation to the classifier.
        classifier.addExample(activation, classId);

        // Dispose the tensor to release the memory.
        img.dispose();
    };

    // When clicking a button, add an example for that class.
    document.getElementById('class-a').addEventListener('click', () => addExample(0));
    document.getElementById('class-b').addEventListener('click', () => addExample(1));
    document.getElementById('class-c').addEventListener('click', () => addExample(2));

}

async function predict() {
    while (isPredict) {
        if (classifier.getNumClasses() > 0) {
            const img = await webcam.capture();

            // Get the activation from mobilenet from the webcam.
            const activation = net.infer(img, 'conv_preds');
            // Get the most likely class and confidences from the classifier module.
            const result = await classifier.predictClass(activation);

            const classes = ['Like', 'Dislike', 'Neutral'];
            document.getElementById('console').innerText = `
        prediction: ${classes[result.label]}\n
        probability: ${result.confidences[result.label]}
      `;
            let arr = Object.values(result.confidences);
            console.log(Math.max(...arr));

            const max = Math.max(...arr);

            if (classes[result.label] === 'Like' && max === result.confidences[result.label]) {

                likeCount = likeCount + 1;
                likeEle.innerText = likeCount;
            }

            if (classes[result.label] === 'Dislike' && max === result.confidences[result.label]) {
                dislikeCount = dislikeCount + 1;
                dislikeEle.innerText = dislikeCount;
            }


            if (classes[result.label] === 'Neutral' && max === result.confidences[result.label]) {
                neutralCount = neutralCount + 1;
                neutralEle.innerText = neutralCount;
            }


            // Dispose the tensor to release the memory.
            img.dispose();
        }

        await tf.nextFrame();
    }
}

async function init() {
    console.log('Loading mobilenet..');

    // Load the model.
    net = await mobilenet.load();
    console.log('Successfully loaded model');

    // Create an object from Tensorflow.js data API which could capture image 
    // from the web camera as Tensor.
    webcam = await tf.data.webcam(webcamElement);

    predict();
}

function stop() {
    isPredict = false;
}


// Initialize the application.
init();